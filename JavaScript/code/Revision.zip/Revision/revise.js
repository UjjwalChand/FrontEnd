// Constructor function
function Movie(title) {
    this.title = title;
}

// const obj = new Constructor()

const movie1 = new Movie('12th Fail');
// console.log(movie1);

movie1.year = 2023;
// console.log(movie1);

// console.log(movie1.__proto__);

const movie2 = new Movie('Animal')
console.log(movie2.__proto__.__proto__.__proto__);


// console.log(a);
// let a = 2;

// f1(){
//     f2(){
//         f3(){

//         }
//     }
// }
// f1();

// Default propagation: (Event bubbling)

// addEventListener(event, listener, boolean)


// == vs ===
// let a = 2;
// let b = '2';
// console.log(a == b); // implicit conversion ==> checks value only
// console.log(a === b); // check value+type


let a = 0;
let b = 0;
let c = a / b;
console.log(c);





