// API:

// Syntax of fetch:

// fetch(url)
//     .then(res => res.json())
//     .then(data => {
//         // working code
//     })
//     .catch(err => {

//     });

// NOTE: fetch API returns a promise.

// function fetchData() {
//     fetch("https://dummyjson.com/products/1")
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error("Response not appropriate");
//             }
//             return response.json(); // Gives data in JSON format.
//         })
//         .then(data => {
//             console.log(data);
//         })
//         .catch(err => {
//             console.log(err);
//         })
// }
// fetchData();

// async/await


async function fetchData(){
    try{
        const response = await fetch("https://dummyjson.com/products/1");
        if(!response.ok){
            throw new Error("Response not appropriate");
        }
        const data = await response.json();
        console.log(data);
    }catch(err){
        console.log(err);
    }
}
fetchData();