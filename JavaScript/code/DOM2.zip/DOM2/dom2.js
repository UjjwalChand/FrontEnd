// // creating an element

// // const btn = document.createElement("button");
// // btn.textContent = "Click Here";
// // btn.className = "btn1";


// // const division = document.querySelector("div");
// // division.appendChild(btn);


// // create a div element
// const createdElement = document.createElement("div");
// // console.log(createdElement);

// // Embedding CSS dynamically :

// createdElement.style.height = "100px";
// createdElement.style.width = "100px";
// createdElement.style.backgroundColor = "blue";

// // Add some content:
// createdElement.innerText = "I am the dynamically created div";

// // appending in HTML:
// document.body.appendChild(createdElement);

// example:

// const categoryFilter = document.getElementById("category-filter");
// const productList = document.getElementById("product-list");


// // syntax: addEventListener('eventName', listener);
// categoryFilter.addEventListener("change", function () {
//     const selectedCategory = categoryFilter.value; // selected a category.

//     // hide/show based on selectedCategory
//     const products = productList.querySelectorAll('.product'); // accessed all the products.

//     products.forEach(product => {
//         const productCategory = product.getAttribute("data-category");

//         if (selectedCategory === "all" || selectedCategory == productCategory) {
//             product.style.display = "block"; // ensures product is displayed when match selected category
//         }
//         else {
//             product.style.display = "none";
//         }
//     });
// });


/* Event Propogation:
Mechanism that defines how events propogate/travel through DOM Tree.

1) Event Bubbling: (child ---> Root) : it is default behavious of JS.
2) Event capturing: (Root ---> child)
*/
// stopPropagation()

// Event Propagation:
// const body = document.getElementsByTagName("body")[0];

// const div = document.getElementsByTagName("div")[0];

// const span = document.getElementsByTagName("span")[0];

// const button = document.getElementsByTagName("button")[0];

// body.addEventListener("click", (e) => {
//     e.stopPropagation();
//     console.log("Body clicked");
// }, true);

// div.addEventListener("click", (e) => {
//     e.stopPropagation();
//     console.log("Div clicked");
// }, true);

// span.addEventListener("click", (e) => {
//     e.stopPropagation();
//     console.log("span clicked");
// }, true);

// button.addEventListener("click", (e) => {
//     e.stopPropagation();
//     console.log("Button clicked");
// }, true);

// Event Delegation:

// document.getElementById("id").addEventListener("click", function () {
//     if (event.target.tagName === "LI") {
//         console.log("Task clicked", event.target.textContent);
//     }
// });
