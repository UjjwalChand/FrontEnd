/*
Definition of JS: JS is synchronous (in a specific order), single threaded language 
(one command at a time).
*/

// console.log("JavaScript"); // Line 1
// console.log("Synchronous"); // Line 2
// console.log("Sigle Threaded"); // Line 3

// Time taking task:
// console.log("Start");

// function operation(){
//     for(let i=0;i<1000000000;i++){
//         // Time pass 
//     }
//     console.log("Finish");
// }
// operation();
// console.log("End");

/*
CONCLUSION:-
No 2 operations are performed at the same time.
We know that, we have only one call stack.==> Only 1 task at a time.
 */


// Asynchronous programming:To achieve 2 or more operations running  at the same time.

/*
JS :
1) Synchronous JS: (Blocking) => UI freeze
2) Asynchronous JS: (Non-Blocking) => Render other parts that do not depend on the server data. 
*/


/* 

Real life example: Doing laundry etc.
*/

/* Async. operations can be done using:
1) setTimeout: delay the execution of passed function by a specified duration.
// Syntax: setTimeout((callback), time in milliseconds)
console.log("Start");
setTimeout(function () {
    console.log("Asynchronous");
}, 2000);

console.log("End");

// Real life usecase: logout, google meet etc.

2) setInterval: used to specify a repeating functions with time delays/interval.

Syntax: setInterval((callback), time in milliseconds);
*/

let intervalID = setInterval(() => {
    console.log("Asynchronous function repeat after every 1 sec");
}, 1000);

// clearInterval to stop the repeated function

setTimeout(function () {
    clearInterval(intervalID);
    console.log("Interval stopped after 5 seconds");
}, 5000);

console.log("End of the program");

// Real life use case: Periodic refersh of the feeds on social networking sites.

/*
API:
1) Browser API:
Browser support set of built-in Web APIs to support complex web operations.
Browser gives JS Engine to use this super power using window keyword.
Aynschronous code forwarded to web APIs environment.

2) Third party API:

*/


