// DOM: Document Object Model

/*
HTML: Structure
CSS: Styling
----------STATIC------------
JS: Behaviour
*/

// API: complex functionality abstracted and provided to us in a simple syntax.

// console.log("DOM");

/* Web APIS
1) Browser APIs (DOM API, Video API, Audio API)
2) 3rd party API (Google map, swiggy, Twitter etc.)
*/

// DOM Manipulation:



/* Selectors
1. getElementsByid/class/name/tagname 


const heading = document.getElementById("id");
console.log(heading); // returns element with specific id.

const heading = document.getElementsByClassName("class");
console.log(heading);


document.querySelector();


DOM Manipulation:

/*
const heading = document.getElementsByTagName("h1");
console.log(heading);
*/

//*****************************************************************************************************/
// Dynamic creation of elements in JS:
// createElement():
const btn = document.createElement("button");
btn.textContent = "Click Here";
btn.className = 'btn1';

const division = document.querySelector("div");
division.appendChild(btn);

//********************************************************************************************************/
// Events: something that happens on the web page (For eg: click, hover, keypress etc.)


// Sytnax: addEventListener(event, listener)

// const p = document.querySelector("h2");
// p.addEventListener("click", clickPara);

// p.addEventListener("click", ()=>{
//     console.log("Para clicked");
// });

// function clickPara() {
//     console.log("para clicked");
// }


// const iphone = document.querySelector("img");
// iphone.onmouseover = function () {
//     console.log("Iphone");
// }






