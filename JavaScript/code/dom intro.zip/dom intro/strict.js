"use strict"

x=10;
console.log(x);