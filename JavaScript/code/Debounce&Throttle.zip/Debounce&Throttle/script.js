// function parent() {
//     var a = 1;
//     var b = 2;
//     function child() {
//         var a1 = 5;
//         var b1 = 6;
//     }
// }

// Without closure:
// let counter = 0;  // Global
// function incrementCounter(){
//     counter++;
// }

// console.log(counter); // 0
// incrementCounter();
// console.log(counter); // 1



// with Closure
// function createCounter() {
//     let count = 0; // local
//     return function () {
//         count++;
//         return count;
//     }
// }

// const counter = createCounter();
// console.log(counter());  
// console.log(counter()); 


// Debouncing

// let count = 0;
// const logger = () => {
//     console.log("Key has been clicked", count++);
// }

// const advancedlogger = debounce(logger, 1000);

// const debounce = function (fxn, delay) {
//     let timer;
//     return function () {
//         timer = setTimeout(() => {
//             fxn();
//         }, delay)
//     }
// }
let count = 0;
const logger = () => {
    console.log("Key has been clicked", count++);
}

const debounce = function (fxn, delay) {
    let timer;
    return function () {
        clearTimeout(timer);
        timer = setTimeout(() => {
            fxn();
        }, delay)
    }
}

const advancedlogger = debounce(logger, 1000);

// const advancedlogger = debounce(logger, 1000);


/* Throttling
Performance optimization
Rate limiting API calls


|======|===============
*/






