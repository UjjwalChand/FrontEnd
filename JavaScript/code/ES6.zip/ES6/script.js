// var num1= 5;
// var num1=6;

// console.log(num1);

// cannot be redeclared within its scope
// let num1 = 5;
// {
//     let num1 = 6;
//     console.log(num1);
// }

// Can be declared without Initialization:
// var a;
// let a;
// const a;

// Update/ re-assign
// let a = 31;
// a = 30;

// TDZ:

// ReferenceError: Cannot access 'a' before initialization
// console.log(a);
// let a; // declare
// a = "Hello World!"; // intialization




// const fs11a = ['Gobinda', 'Prateek'];
// const fs11b = ['Anvesh', 'Mantu', 'Samarth'];
// const fs11c = ['Jishu', 'Ankit'];
// const fs11m5 = []; // new batch

// function addStudent(batch, student) {
//     batch.push(student);
//     console.log(batch);
// }

// // addStudent(fs11m5, 'Gaurav');
// // addStudent(fs11m5, 'xyz');



// // Rest 
// function addStudents(batch, ...students) {
//     for (let i of students) {
//         batch.push(i);
//     }
//     console.log(batch);
// }

// // addStudents(fs11m5, 'newStudent1', 'newStudent2', 'newStudent3');

// // Spread:
// const newBatch = [...fs11b];
// // console.log(newBatch);

// console.log(...fs11a, ...fs11b);

// Destructuring

// Object Destructuring
const person = { name: 'Gaurav', age: 29 };
// console.log(person.name);
// console.log(person.age);

// const { name, age } = person; // object destructuring
// console.log(name);
// console.log(age);


// const { name: firstName, age:Age } = person;
// console.log(firstName);
// console.log(Age);

// Array destructuring

// const numbers = [1, 2, 3, 4, 5];
// // const [a, b, c] = numbers; // Array destructuring
// const [a, , b, c] = numbers;
// console.log(a);
// console.log(b);
// console.log(c);

// Set:
const uniqueNumbers = new Set([1, 2, 3, 1, 2]);

const uniqueChars = new Set("Hello");
console.log(uniqueChars);
console.log(uniqueNumbers);
